import React from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, useGLTF } from '@react-three/drei';
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { useRef } from "react";
import Projects from "./Projects.js";
import Typewriter from "typewriter-effect";
import FloatingLogos from "./FloatingLogos.js";
import Contact from "./Contact.js";
import About from "./About.js"; // Page À propos

// Modèle 3D de l'ordinateur
function ComputerModel() {
  const { scene } = useGLTF('/models/laptop.glb'); // Charger le modèle GLTF
  const laptopRef = useRef();

  // Animation : rotation continue du modèle
  useFrame(() => {
    if (laptopRef.current) {
      laptopRef.current.rotation.y += 0.01; // Rotation lente sur l'axe Y
    }
  });

  return (
    <mesh ref={laptopRef}>
      <primitive object={scene} scale={5} position={[0, -1, 0]} />
    </mesh>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-gray-200">
        {/* Barre de navigation */}
        <header className="py-4 navbar">
          <div className="container mx-auto px-4 flex justify-between items-center">
            <h1 className="text-2xl font-bold text-teal-400">LD</h1>
            <nav>
              <ul className="flex space-x-6">
                <li>
                  <Link to="/about" className="hover:text-teal-400">À propos</Link>
                </li>
                <li>
                  <Link to="/" className="hover:text-teal-400">Home</Link>
                </li>
                <li>
                  <a href="/#projects" className="hover:text-teal-400">Projets</a>
                </li>
                <li>
                  <a href="#contact" className="hover:text-teal-400">Contact</a>
                </li>
              </ul>
            </nav>
          </div>
        </header>

        {/* Routes */}
        <Routes>
          {/* Route pour la page d'accueil */}
          <Route
            path="/"
            element={
              <>
                {/* Section d'Introduction */}
                <section className="container mx-auto px-4 py-40 text-center">
                  <h2 className="text-1xl font-extrabold text-teal-400 mb-4 glitch-effect z-10">
                              
                  <Typewriter
                        options={{
                          strings: ["Lucas Djavid", "Developper Full-Stack", "Cyber Analyst"],
                          autoStart: true,
                          loop: true,
                          deleteSpeed: 50,
                        }}
                      />
                  </h2>
                  <p className="text-lg text-gray-400 mb-8">

                  </p>
                  <a href="#projects" className="px-5 py-3 bg-teal-500 text-white font-semibold rounded hover:bg-teal-600 relative z-10 ">
                    Voir mes projets
                  </a>
                  <FloatingLogos numberOfLogos={30} />

                  <div className="mt-16 flex justify-center relative">
                    {/* Canvas avec le modèle 3D */}
                    <Canvas style={{ height: '300px', width: '500px' }} shadows>
                      <ambientLight intensity={1.5} />
                      {/* Utilisation de pointLight de @react-three/fiber */}
                      <pointLight position={[5, 5, 5]} intensity={1} color="#ffffff" />
                      <PerspectiveCamera makeDefault position={[0, 1, 5]} />
                      <OrbitControls enableZoom={false} />
                      <ComputerModel />
                    </Canvas>
                  </div>
                </section>

                {/* Section des Projets */}
                <Projects />

                {/* Section Contact */}
                <Contact />
              </>
            }
          />

          {/* Route pour la page About */}
          <Route path="/about" element={<About />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
