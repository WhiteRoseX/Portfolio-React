import React, { useState } from "react";
import { motion } from "framer-motion"; // Import de framer-motion
import ProjectModal from "./Modal"; // Assure-toi que ton Modal est bien configuré avec des animations

function Projects() {
  const [selectedProject, setSelectedProject] = useState(null);

  const projects = [
    {
      id: 1,
      title: "Pacman en Python",
      description: "This is a small pacman made with library Pygame in Python, including smart enemies realized with basics of algorithmic..",
      image: "/img/pacman.png",
    },
    {
      id: 2,
      title: "ÉchangeLivre",
      description: "Application based on vite + react working with component",
      image: "/img/Échange-Livre.png",
    },
    {
      id: 3,
      title: "Hand tracker",
      description: "My first computer vision project made with python based on OpenCV and MediaPipe - Hand Tracker",
      image: "/img/hand.jpg",
    },
  ];

  return (
    <section id="projects" className="bg-gray-900 py-20">
      <div className="container mx-auto px-4">
        <h3 className="text-3xl font-bold text-teal-400 text-center mb-8 tracking-wider glitch-effect">
          Mes Projets
        </h3>
        <br />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 100 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="group relative bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden"
                >
                {/* Gradient lumineux au survol */}
                <div
                    className="absolute inset-0 bg-gradient-to-r from-teal-500 via-transparent to-transparent opacity-0 group-hover:opacity-50 transition-opacity duration-500"
                    style={{ pointerEvents: "none" }}
                ></div>

                {/* Image */}
                <img
                    src={project.image}
                    alt={project.title}
                    className="rounded mb-4 w-full h-40 object-cover"
                />

                {/* Titre */}
                <h4 className="text-xl font-semibold text-teal-300 mb-2 text-center">
                    {project.title}
                </h4>

                {/* Description */}
                <p className="text-gray-300 text-center mt-2">
                    {project.description.substring(0, 50)}...
                </p>

                {/* Bouton */}
                <div className="flex justify-center mt-4 w-full">
                    <button
                    onClick={() => setSelectedProject(project)}
                    className="px-6 py-2 relative text-white font-semibold rounded bg-teal-500 hover:bg-teal-600 overflow-hidden"
                    >
                    <span className="absolute inset-0 bg-gradient-to-r from-teal-400 to-teal-600 opacity-30"></span>
                    <span className="relative z-10">En savoir plus</span>
                    </button>
                </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Modal */}
      <ProjectModal
        isOpen={selectedProject !== null}
        onClose={() => setSelectedProject(null)}
        title={selectedProject?.title}
        description={selectedProject?.description}
        image_path={selectedProject?.image}
      />
    </section>
  );
}

export default Projects;
