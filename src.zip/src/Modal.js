import React, { useState } from "react";
import { motion } from "framer-motion";

function ProjectModal({ isOpen, onClose, title, description, image_path }) {
  if (!isOpen) return null;

  // Animation pour la modal
  const modalVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.3 } },
  };

  // Animation pour l'arrière-plan de la modal
  const backdropVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 1 } },
  };

  return (
    <>
      {/* Arrière-plan de la modal avec animation */}
      <motion.div
        className="fixed inset-0 bg-black bg-opacity-50 z-50"
        variants={backdropVariants}
        initial="hidden"
        animate="visible"
        onClick={onClose}
      ></motion.div>

      {/* Contenu du modal avec animation */}
      <motion.div
        className="fixed inset-0 flex items-center justify-center z-50"
        variants={modalVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="bg-gray-800 text-white p-6 rounded-lg shadow-lg w-3/4 md:w-1/2 relative">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-gray-300 hover:text-white"
          >
            ✕
          </button>
          {/* Image avec animation de taille et opacité */}
          <motion.img
            src={image_path}
            className="rounded mb-4 w-40 h-40 object-cover"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          />
          <h3 className="text-2xl font-bold text-teal-400 mb-4">{title}</h3>
          <p className="text-gray-300 mb-6">{description}</p>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-teal-500 text-white font-semibold rounded hover:bg-teal-600"
          >
            Fermer
          </button>
        </div>
      </motion.div>
    </>
  );
}

export default ProjectModal;
